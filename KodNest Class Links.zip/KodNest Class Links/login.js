function check(form)
                {
                 
                 if(form.searchClass.value == "java")
                  {
                    window.open('https://zoom.us/j/92264755733?pwd=bWVQZUpSclJzeHlrM21CMzRUUlFTdz09')
                  }
                 else if(form.searchClass.value == "mysql")
                 {
                    window.open('https://zoom.us/j/99723988748?pwd=UEJLZE1zY1Urb0NDWXEvVDNEb0FOdz09')
                 }
                 else if(form.searchClass.value == "web")
                 {
                    window.open('https://zoom.us/j/97951978765?pwd=NEFES25qRldpT2V6Zm5SWW9FZmZjZz09')
                 }
                 else if(form.searchClass.value == "book")
                 {
                    window.open('https://classroom.google.com/c/NTU1MTQxMzU2MTU5/m/NTU1MTQ4MTcwMjU0/details')
                 }
                 else
                 {
                   alert("Enter Correct Class")
                  }
                }